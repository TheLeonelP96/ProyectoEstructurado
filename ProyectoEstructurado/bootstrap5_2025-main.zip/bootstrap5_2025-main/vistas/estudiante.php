<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    include "menu.php";
    ?>
    <div class="container">
        <label for="">Lista estudiantes</label>
        <div class="row">
            <div class="col-md-6">

            </div>
        </div>
    </div>
</body>
</html>