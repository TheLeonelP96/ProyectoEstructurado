<?php

$conexion= mysqli_connect('localhost','root','','proyectoestructura') 
or die ('no existe la conexion');




?>